const express = require("express");
const session = require("express-session"); // to be used to keep track of user sessions
const axios = require("axios");
var bodyParser = require("body-parser");
const app = express();
const path = require("path"); // Import the 'path' module

app.set("view engine", "ejs");

// Requires to safely store files
require("dotenv").config();

app.use(express.static('public\views'));

// create application/json parser
var jsonParser = bodyParser.json();

// create application/x-www-form-urlencoded parser
var urlencodedParser = bodyParser.urlencoded({ extended: false });

//WeatherBudy API Key + Value
const API_KEY = "1bd54b31a2b58876a9f3d94a42736a02";
const CITY_NAME = "Montreal";
//process.env.WeatherAPI_KEY

//Passport/Google Config
const passport = require("passport");
const GoogleStrategy = require("passport-google-oauth2").Strategy;

const GOOGLE_CLIENT_ID = "319549218879-0j13ugguknb0b5b6o2lfeii9ngguq14d.apps.googleusercontent.com";
const GOOGLE_CLIENT_SECRET = "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";
const GOOGLE_SESSION_SECRETS = 'cats'
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
passport.use(
  new GoogleStrategy(
    {
      clientID: GOOGLE_CLIENT_ID,
      clientSecret: GOOGLE_CLIENT_SECRET,
      callbackURL: "http://localhost:3000/google/callback",
      passReqToCallback: true,
    },

    function (request, accessToken, refreshToken, profile, done) {
      return done(err, profile);
    }
  )
);

passport.serializeUser(function (user, done) {
  done(null, user);
});

passport.deserializeUser(function (user, done) {
  done(null, user);
});

// Middleware function, takes request and passes it on
function isAuth(req, res, next) {
  req.user ? next() : res.sendStatus(401);
}
function toCelsius(kelvin) {
    return Math.round(kelvin - 273.15);
  }
  

app.get("/", async (req, res) => {
  const blogs = [
    { title: "Blog 1", snippet: "Lorem ipsum dolor sit amet consectetur" },
    { title: "Blog 2", snippet: "Lorem ipsum dolor sit amet consectetur" },
    { title: "Blog 3", snippet: "Lorem ipsum dolor sit amet consectetur" },
  ];
  let TempLocation = 0;

  await axios
    .get(
      `https://api.openweathermap.org/data/2.5/weather?q=${CITY_NAME}&appid=${API_KEY}`
    )

    .then((respond) => {
      const data = respond.data;
      const tempInKelvin = respond.data["main"].temp;
      TempLocation = tempInKelvin - 273.15;
      TempLocation = Math.round(TempLocation);
      res.render("index", {
        title: "Homepage",
        // temperature: TempLocation,
        city: CITY_NAME,
        
        data,
        toCelsius,
      });
    })
    .catch((err) => {
      console.log(err);
    });
});

app.get("/city", async (req, res) => {
  const city = req.query.city;
  try {
    const response = await axios.get(
      `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}`
    );
    const data = response.data;

    // res.json(data);
    const tempInKelvin = response?.data["main"].temp;
    let temperature = Math.round(tempInKelvin - 273.15);
    res.render("index", {
      title: "Homepage",
      temperature,
      data,
      toCelsius,
    });
  } catch (error) {
    console.error(error);
    res.status(500).send("API call failed.");
  }
});
app.get("/forecast", async (req, res) => {
  const city = req.query.city;
  try {
    const response = await axios.get(
      `https://api.openweathermap.org/data/2.5/forecast?q=${city}&appid=${API_KEY}`
    );
    const data = response.data;

    const forecastData = {};
    data?.list?.forEach((item) => {
      const dateString = item?.dt_txt?.split(" ")[0];
      if (forecastData.hasOwnProperty(dateString)) {
        forecastData[dateString].push(item);
      } else {
        forecastData[dateString] = [item];
      }
    });

    res.render("forecast", {
      title: "Forecast for " + data?.city?.name,
      data,
      forecastData,
      toCelsius,
    });
  } catch (error) {
    console.error(error);
    res.status(500).send("API call failed.");
  }
});

app.get("/forecast", (req, res) => {
  res.render("forecast", { title: "About" });
});

app.get("/login", (req, res) => {
  res.render("login", { title: "Login Page" });
});
app.get("/about", (req, res) => {
  res.render("about", { title: "Login Page" });
});


// checking creds with GOOGLE
app.get(
  "/auth/google",
  passport.authenticate("google", { scope: ["email", "profile"] })
);

app.get(
  "goole/callback",
  passport.authenticate("google", {
    successRedirect: "/userProfile",
    failureRedirect: "/login",
  })
);

// User Page
app.get("/userProfile", isAuth, (req, res) => {
  res.render("Hello, ${req.user.displayName}", "userProfile", {
    title: "Climate",
  });
});

// Logout Page
app.get("/logout", (req, res) => {
  req.logout();
  req.session.destroy();
  res.render("Enjoy Your Day!");
});

// For sessions use
app.use(session({ secret: "cats" }));
app.use(passport.initialize());
app.use(passport.session());

app.use("/url", (req, res) => {
  res.status(404).render("404", { title: "404" });
});

app.listen(3000, () => {
  console.log("Server is listening on port 3000");
});
