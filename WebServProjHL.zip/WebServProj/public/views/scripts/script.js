function displayDateTime()
{
    var currentDate = new Date(); 
    var dateDisplay = {year: "numeric", month: "long", day: "numeric"};
    var timeDisplay = {hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: true };
    var formattedDate = currentDate.toLocaleDateString(undefined, dateDisplay);
    var formattedTime = currentDate.toLocaleTimeString(undefined, timeDisplay);
    var dateTimeString = formattedDate + " " + formattedTime;

    document.getElementById("dateTime").textContent = dateTimeString;
}

// Call function when page is loaded.
window.onload = displayDateTime;